from dataclasses import dataclass

from sqlalchemy.ext.asyncio import AsyncSession

from infrastructure.database.repo.users import UserRepo
from infrastructure.database.setup import create_engine, create_session_pool

from tgbot.config import load_config


config = load_config(".env")
engine = create_engine(config.db)
print(config.db)
session_pool = create_session_pool(engine)


@dataclass
class RequestsRepo:
    """
    Repository for handling database operations. This class holds all the repositories for the database models.

    You can add more repositories as properties to this class, so they will be easily accessible.
    """

    session: AsyncSession

    @property
    def users(self) -> UserRepo:
        """
        The User repository sessions are required to manage user operations.
        """
        return UserRepo(self.session)


async def create_user(user_id, full_name, username):
    async with session_pool() as session:
        repo = RequestsRepo(session)
        await repo.users.create_user(
            user_id=user_id,
            full_name=full_name,
            username=username
        )


async def get_user(user_id):
    async with session_pool() as session:
        repo = RequestsRepo(session)
        return await repo.users.get_user(user_id)


async def get_user_by_username(username):
    async with session_pool() as session:
        repo = RequestsRepo(session)
        return await repo.users.get_user_by_username(username)


async def user_is_registered(user_id):
    user = await get_user(user_id)
    return True if user else False


async def user_is_banned(user_id):
    user = await get_user(user_id)
    return True if user is not None and user.banned else False


async def update_user(user_id, **kwargs):
    async with session_pool() as session:
        repo = RequestsRepo(session)
        await repo.users.update_user(user_id, **kwargs)


async def get_active_users():
    async with session_pool() as session:
        repo = RequestsRepo(session)
        return await repo.users.get_active_users()


async def get_all_users():
    async with session_pool() as session:
        repo = RequestsRepo(session)
        return await repo.users.get_all_users() 